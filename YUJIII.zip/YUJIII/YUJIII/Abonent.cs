﻿namespace YUJIII
{
    public class Abonent
    {
        public string Name { get; set; } = "";
        public string LastName { get; set; } = "";
        public string FathersName { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Age { get; set; } = "";
    }
}