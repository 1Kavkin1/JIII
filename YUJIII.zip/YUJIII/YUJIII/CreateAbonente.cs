using System;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Collections.Generic;
using System.Windows.Forms;

namespace YUJIII
{
    public partial class CreateAbonente : Form
    {
        private ErrorProvider errorProvider;
        private string filePath;
        private ContextMenuStrip contextMenu;

        public CreateAbonente()
        {
            InitializeComponent();

            errorProvider = new ErrorProvider();
            errorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;

            filePath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                "contacts.json");

            textBoxName.TextChanged += ValidateField;
            textBoxLastName.TextChanged += ValidateField;
            textBoxDadsName.TextChanged += ValidateField;
            textBoxPhone.TextChanged += ValidateField;
            textBoxAge.TextChanged += ValidateField;

            buttonAccept.Click += ButtonAccept_Click;
            buttonStop.Click += ButtonStop_Click;

            contextMenu = new ContextMenuStrip();
            var deleteItem = new ToolStripMenuItem("��������");
            deleteItem.Click += DeleteItem_Click;
            contextMenu.Items.Add(deleteItem);

            listBoxAbonents.ContextMenuStrip = contextMenu;

            LoadAbonentsFromFile();
        }


        private List<Abonent> LoadAbonents()
        {
            if (!File.Exists(filePath))
                return new List<Abonent>();

            string json = File.ReadAllText(filePath);

            return JsonSerializer.Deserialize<List<Abonent>>(json)
                   ?? new List<Abonent>();
        }

        private void SaveAbonents(List<Abonent> list)
        {
            string json = JsonSerializer.Serialize(list,
                new JsonSerializerOptions { WriteIndented = true });

            File.WriteAllText(filePath, json);
        }



        private void LoadAbonentsFromFile()
        {
            listBoxAbonents.Items.Clear();

            var list = LoadAbonents();

            foreach (var a in list)
            {
                listBoxAbonents.Items.Add(
                    $"{a.Name} {a.LastName} - {a.Phone}");
            }
        }


        private void ButtonAccept_Click(object? sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            var list = LoadAbonents();

            list.Add(new Abonent
            {
                Name = textBoxName.Text,
                LastName = textBoxLastName.Text,
                FathersName = textBoxDadsName.Text,
                Phone = textBoxPhone.Text,
                Age = textBoxAge.Text
            });

            SaveAbonents(list);

            LoadAbonentsFromFile();
            ClearFields();
        }

        // ================= DELETE =================

        private void DeleteItem_Click(object? sender, EventArgs e)
        {
            if (listBoxAbonents.SelectedItem == null)
                return;

            string selected = listBoxAbonents.SelectedItem.ToString();
            string phone = selected.Split('-')[1].Trim();

            var list = LoadAbonents();

            list.RemoveAll(x => x.Phone == phone);

            SaveAbonents(list);
            LoadAbonentsFromFile();
        }

        // ================= VALIDATION =================

        private bool ValidateForm()
        {
            bool valid = true;

            if (!ValidateSingleField(textBoxName, "������ ��'�!"))
                valid = false;

            if (!ValidateSingleField(textBoxLastName, "������ �������!"))
                valid = false;

            if (!ValidateSingleField(textBoxDadsName, "������ �� �������!"))
                valid = false;

            if (!ValidateSingleField(textBoxPhone, "������ �������!"))
                valid = false;

            if (!int.TryParse(textBoxAge.Text, out int age) || age <= 0)
            {
                errorProvider.SetError(textBoxAge, "������ ��������� ��!");
                textBoxAge.BackColor = Color.MistyRose;
                valid = false;
            }
            else
            {
                errorProvider.SetError(textBoxAge, "");
                textBoxAge.BackColor = Color.White;
            }

            return valid;
        }

        private bool ValidateSingleField(TextBox box, string message)
        {
            if (string.IsNullOrWhiteSpace(box.Text))
            {
                errorProvider.SetError(box, message);
                box.BackColor = Color.MistyRose;
                return false;
            }

            errorProvider.SetError(box, "");
            box.BackColor = Color.White;
            return true;
        }

        private void ValidateField(object? sender, EventArgs e)
        {
            if (sender is TextBox box)
            {
                if (string.IsNullOrWhiteSpace(box.Text))
                {
                    errorProvider.SetError(box, "���� �� ���� ���� ��������!");
                    box.BackColor = Color.MistyRose;
                }
                else
                {
                    errorProvider.SetError(box, "");
                    box.BackColor = Color.White;
                }
            }
        }


        private void ButtonStop_Click(object? sender, EventArgs e)
        {
            Close();
        }

        private void ClearFields()
        {
            textBoxName.Clear();
            textBoxLastName.Clear();
            textBoxDadsName.Clear();
            textBoxPhone.Clear();
            textBoxAge.Clear();
        }

        private void listBoxAbonents_SelectedIndexChanged(object? sender, EventArgs e)
        {
            if (listBoxAbonents.SelectedItem == null)
                return;

            MessageBox.Show(listBoxAbonents.SelectedItem.ToString());
        }
    }
}